# Circuit Segmentation > 2023-12-05 7:58pm
https://universe.roboflow.com/ethan-muchnik-minqm/circuit-segmentation

Provided by a Roboflow user
License: CC BY 4.0

