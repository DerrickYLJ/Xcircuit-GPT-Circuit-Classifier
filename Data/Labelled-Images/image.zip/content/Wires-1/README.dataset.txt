# Wires > 2023-10-30 2:41pm
https://universe.roboflow.com/ethan-muchnik-minqm/wires-3ev6e

Provided by a Roboflow user
License: CC BY 4.0

